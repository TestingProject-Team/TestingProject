# BẢNG TỔNG KẾT VÀ TRA CỨU HÌNH ẢNH SƠ ĐỒ KỸ THUẬT (TECHNICAL DIAGRAMS INDEX)
## Dự án: YiYi Book - Hệ thống Thương mại Điện tử Bán Sách Trực tuyến & Trợ lý Tư vấn AI

---

### 1. NGUYÊN TẮC THIẾT KẾ VÀ TIÊU CHUẨN ĐỒ HỌA
Toàn bộ sơ đồ kiến trúc và kỹ thuật của đồ án tốt nghiệp YiYi Book được xây dựng tự động dựa trên **100% dữ liệu thực tế trích xuất từ mã nguồn backend (Spring Boot 3.x, Hibernate JPA, PostgreSQL 16) và frontend (React 18, Vite)**:
- **01_infographic (Enterprise Architecture Style)**: Phong cách đồ họa hiện đại, thẻ phân lớp màu sắc trang nhã, phân cấp thị giác rõ ràng, đường kết nối sắc nét, trực quan cho hội đồng đánh giá và độc giả kỹ thuật.
- **02_standard (Standard Technical UML Style)**: Phong cách chuẩn UML quốc tế, viền đen trắng tối giản, typography đơn giản, chuẩn mực kỹ thuật công nghệ phần mềm.
- **Tiêu chuẩn chống crop (Anti-crop Rule)**: Toàn bộ canvas duy trì Safe Margin $\ge 60\text{ px}$, tỉ lệ khung hình chuẩn A4 ngang ($2000 \times 1300$ hoặc $2400 \times 1600$), độ phân giải cao $300\text{ DPI}$, đảm bảo khi chèn vào Microsoft Word không bị che khuất hay tràn mép.
- **Định dạng bàn giao**: Cung cấp đồng thời cả **PNG 300 DPI** (chèn văn bản) và **SVG vector editable** (chỉnh sửa vector).

---

### 2. BẢNG MAPPING CHI TIẾT SƠ ĐỒ VÀ MÃ NGUỒN KIỂM CHỨNG

| STT | Mã Hình DOCX | Tên sơ đồ chi tiết | Tệp PNG / SVG tương ứng | Kích thước & DPI | Nguồn mã kiểm chứng (Source Verification) |
|---|---|---|---|---|---|
| 1 | **Hình 2.1** | Sơ đồ quy trình phát triển phần mềm Agile/Scrum của dự án YiYi Book | `Hinh_2.1_Agile_Scrum_Workflow_YiYi_Book.png`<br>`Hinh_2.1_Agile_Scrum_Workflow_YiYi_Book.svg` | $2000 \times 1300$<br>300 DPI | Quy trình Sprint 2 tuần, Jira Backlog, GitHub Actions CI/CD, SonarQube & CodeceptJS. |
| 2 | **Hình 4.3** | Kiến trúc phân tầng Backend Spring Boot | `Hinh_4.3_Backend_Layered_Architecture.png`<br>`Hinh_4.3_Backend_Layered_Architecture.svg` | $2000 \times 1300$<br>300 DPI | 23 REST Controllers, 15 Services, 18 Repositories, Spring Security JWT Filter, HikariCP Pool. |
| 3 | **Hình 4.4** | Kiến trúc luồng tích hợp Trợ lý AI và xử lý ngôn ngữ tự nhiên | `Hinh_4.4_AI_RAG_Intent_Flow_Architecture.png`<br>`Hinh_4.4_AI_RAG_Intent_Flow_Architecture.svg` | $2000 \times 1300$<br>300 DPI | `AIChatWidget.jsx`, Client-side RAG Cache (5000 books), Intent Classifier (6 intents), Groq Llama-3.3-70b. |
| 4 | **Hình 4.5** | Sơ đồ phân rã gói phần mềm hệ thống (Package Diagram) | `Hinh_4.5_Package_Diagram_YiYi_Book.png`<br>`Hinh_4.5_Package_Diagram_YiYi_Book.svg` | $2000 \times 1300$<br>300 DPI | `com.bookstore.*` (controller, service, model, repository, config, dto, exception, security) & `frontend/src/*`. |
| 5 | **Hình 4.6** | Sơ đồ thực thể quan hệ cơ sở dữ liệu (ERD 21 bảng & 4 Enums) | `Hinh_4.6_ERD_Database_YiYi_Book.png`<br>`Hinh_4.6_ERD_Database_YiYi_Book.svg` | $2400 \times 1600$<br>300 DPI | 21 Entities PostgreSQL 16 (users, books, orders, coupons, rewards...) & 4 Enums (Role, AuthProvider...). |
| 6 | **Hình 4.7** | Sơ đồ lớp (Class Diagram) và Tuần tự luồng Xác thực JWT | `Hinh_4.7_Class_Sequence_Diagram_Login_Auth.png`<br>`Hinh_4.7_Class_Sequence_Diagram_Login_Auth.svg` | $2000 \times 1300$<br>300 DPI | `AuthController.java`, `AuthService.java`, `JwtTokenProvider.java`, `JwtAuthFilter.java`, `SecurityConfig.java`. |
| 7 | **Hình 4.12** | Sơ đồ lớp và Tuần tự (Class/Sequence Diagram) Đặt hàng COD & Giảm giá | `Hinh_4.12_Class_Sequence_Diagram_Checkout_COD.png`<br>`Hinh_4.12_Class_Sequence_Diagram_Checkout_COD.svg` | $2000 \times 1300$<br>300 DPI | `OrderService.java`, `CartService.java`, `CouponService.java`, `PointTransactionService.java`. |
| 8 | **Hình 4.13** | Sơ đồ lớp và Tuần tự (Class/Sequence Diagram) Tích hợp Cổng thanh toán Online | `Hinh_4.13_Class_Sequence_Diagram_Payment_Online.png`<br>`Hinh_4.13_Class_Sequence_Diagram_Payment_Online.svg` | $2400 \times 1600$<br>300 DPI | `PaymentController.java`, `VNPayConfig.java`, `MoMoConfig.java`, `ZaloPayConfig.java`, HMAC-SHA512. |
| 9 | **Hình 4.14** | Sơ đồ trạng thái (State Diagram) & Tuần tự luồng Đơn hàng và Đổi trả | `Hinh_4.14_Order_State_Return_Sequence_Diagram.png`<br>`Hinh_4.14_Order_State_Return_Sequence_Diagram.svg` | $2400 \times 1600$<br>300 DPI | `Order.java`, `ReturnRequest.java`, `OrderService.java` (7 ngày hoàn trả, rollback tồn kho và điểm). |
| 10 | **Hình 4.16** | Sơ đồ thành phần và Tuần tự (Component/Sequence Diagram) Trợ lý AI | `Hinh_4.16_Component_Sequence_Diagram_YiYi_AI.png`<br>`Hinh_4.16_Component_Sequence_Diagram_YiYi_AI.svg` | $2000 \times 1300$<br>300 DPI | `AIChatWidget.jsx`, `BookController.java`, `Groq Cloud API` (`llama-3.3-70b-versatile`). |

---

### 3. CẤU TRÚC THƯ MỤC LƯU TRỮ TRONG DỰ ÁN

```text
ảnh file docx/
├── IMAGE_INDEX_ROO.md                                       # Tài liệu chỉ mục & hướng dẫn tra cứu này
├── 01_infographic/                                          # Thư mục chứa sơ đồ phong cách Infographic hiện đại
│   ├── Hinh_2.1_Agile_Scrum_Workflow_YiYi_Book.png
│   ├── Hinh_2.1_Agile_Scrum_Workflow_YiYi_Book.svg
│   ├── Hinh_4.3_Backend_Layered_Architecture.png
│   ├── Hinh_4.3_Backend_Layered_Architecture.svg
│   ├── Hinh_4.4_AI_RAG_Intent_Flow_Architecture.png
│   ├── Hinh_4.4_AI_RAG_Intent_Flow_Architecture.svg
│   ├── Hinh_4.5_Package_Diagram_YiYi_Book.png
│   ├── Hinh_4.5_Package_Diagram_YiYi_Book.svg
│   ├── Hinh_4.6_ERD_Database_YiYi_Book.png
│   ├── Hinh_4.6_ERD_Database_YiYi_Book.svg
│   ├── Hinh_4.7_Class_Sequence_Diagram_Login_Auth.png
│   ├── Hinh_4.7_Class_Sequence_Diagram_Login_Auth.svg
│   ├── Hinh_4.12_Class_Sequence_Diagram_Checkout_COD.png
│   ├── Hinh_4.12_Class_Sequence_Diagram_Checkout_COD.svg
│   ├── Hinh_4.13_Class_Sequence_Diagram_Payment_Online.png
│   ├── Hinh_4.13_Class_Sequence_Diagram_Payment_Online.svg
│   ├── Hinh_4.14_Order_State_Return_Sequence_Diagram.png
│   ├── Hinh_4.14_Order_State_Return_Sequence_Diagram.svg
│   ├── Hinh_4.16_Component_Sequence_Diagram_YiYi_AI.png
│   └── Hinh_4.16_Component_Sequence_Diagram_YiYi_AI.svg
└── 02_standard/                                             # Thư mục chứa sơ đồ phong cách UML Chuẩn đen trắng
    ├── Hinh_2.1_Agile_Scrum_Workflow_YiYi_Book.png
    ├── Hinh_2.1_Agile_Scrum_Workflow_YiYi_Book.svg
    ├── Hinh_4.3_Backend_Layered_Architecture.png
    ├── Hinh_4.3_Backend_Layered_Architecture.svg
    ├── Hinh_4.4_AI_RAG_Intent_Flow_Architecture.png
    ├── Hinh_4.4_AI_RAG_Intent_Flow_Architecture.svg
    ├── Hinh_4.5_Package_Diagram_YiYi_Book.png
    ├── Hinh_4.5_Package_Diagram_YiYi_Book.svg
    ├── Hinh_4.6_ERD_Database_YiYi_Book.png
    ├── Hinh_4.6_ERD_Database_YiYi_Book.svg
    ├── Hinh_4.7_Class_Sequence_Diagram_Login_Auth.png
    ├── Hinh_4.7_Class_Sequence_Diagram_Login_Auth.svg
    ├── Hinh_4.12_Class_Sequence_Diagram_Checkout_COD.png
    ├── Hinh_4.12_Class_Sequence_Diagram_Checkout_COD.svg
    ├── Hinh_4.13_Class_Sequence_Diagram_Payment_Online.png
    ├── Hinh_4.13_Class_Sequence_Diagram_Payment_Online.svg
    ├── Hinh_4.14_Order_State_Return_Sequence_Diagram.png
    ├── Hinh_4.14_Order_State_Return_Sequence_Diagram.svg
    ├── Hinh_4.16_Component_Sequence_Diagram_YiYi_AI.png
    └── Hinh_4.16_Component_Sequence_Diagram_YiYi_AI.svg
```

---
*Tài liệu và hình ảnh được tạo hoàn chỉnh bởi Technical Diagram Designer Roo.*
